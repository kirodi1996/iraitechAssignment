import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-y',
  templateUrl: './y.component.html',
  styleUrls: ['./y.component.scss']
})
export class YComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
